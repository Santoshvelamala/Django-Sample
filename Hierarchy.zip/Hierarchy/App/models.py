# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.db import models
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
from unixtimestampfield.fields import UnixTimeStampField
from django.forms import PasswordInput
# Create your models here.
from django import forms



class Employees(models.Model):
	Name = models.CharField(max_length=100)
	Designation = models.CharField(max_length=20)
	Manager = models.ForeignKey('self', on_delete=models.CASCADE, blank=True, null=True)
	def __str__(self):
		 return str(self.Name)



