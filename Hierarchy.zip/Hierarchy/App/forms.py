from django import forms
from .models import Employees
data = Employees.objects.all()
i=0;
CHOICES=[]
for d in data:
	i=i+1
	CHOICES.append([i,d.Name])

#CHOICES= [tuple([x,x]) for x in range(1,32)]

class DriverLoginForm(forms.Form):
    Name = forms.CharField(label='Name',max_length=100)
    Designation = forms.CharField(label='<br>Designation',max_length=20)
    Manager= forms.CharField(label="<br>Manager", widget=forms.Select(choices=CHOICES))

