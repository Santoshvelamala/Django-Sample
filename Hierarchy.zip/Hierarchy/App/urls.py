from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^$', views.rend, name='rend'),
    url(r'^Hierarchy$', views.rend1, name='rend1'),
#    url(r'^driverregister/$', views.DriverRegister, name='DriverRegister'),
]
