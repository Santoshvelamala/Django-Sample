# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .models import Employees
from .serializers import EmployeesSerializer


from rest_framework import generics
from django.template import RequestContext
from django.shortcuts import render_to_response
from django.template import loader
from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from .forms import DriverLoginForm


def rend(request):
	data = Employees.objects.all()
	form = DriverLoginForm(request.POST)
	if form.is_valid():
		Name=form.cleaned_data['Name']
		Designation=form.cleaned_data['Designation']
		Manager=form.cleaned_data['Manager']
		p = Employees()
		p.Name= Name
		p.Designation= Designation
		p.Manager= Employees.objects.get(id=Manager)
    		p.save()
	else:
        	form = DriverLoginForm(request.POST)
        return render(request, 'clientapp/home.html',context={'form':form})


def rend1(request):
	data = Employees.objects.all()
        return render(request, 'clientapp/home1.html',context={'data':data})



class EmployeesList(generics.ListCreateAPIView):
	queryset = Employees.objects.all()
	serializer_class = EmployeesSerializer

class EmployeesDetail(generics.RetrieveUpdateDestroyAPIView):
	queryset = Employees.objects.all()
	serializer_class = EmployeesSerializer
