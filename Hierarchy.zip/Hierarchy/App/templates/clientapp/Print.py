def func(Manager):
	return Manager
